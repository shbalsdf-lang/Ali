ALI FPS - Android project
========================
هذا مشروع Android Studio جاهز لتحويل لعبة ALI FPS إلى تطبيق.

فتح المشروع:
1) افتح مجلد ALI_FPS_Android في Android Studio.
2) انتظر Gradle Sync.
3) Build > Build APK(s) لإنشاء APK للتجربة.
4) للنشر على Google Play استخدم Build > Generate Signed App Bundle / APK
   واختر Android App Bundle (AAB).

ملاحظة: المشروع مضبوط على الوضع الأفقي، واللعبة تعمل داخل WebView.
